/*
============================================================================
Name        : server_esonero.c
Author      : Angela Lorusso (Matricola:798413)
Version     : 08/11/2024
Copyright   : Your copyright notice
Description : server creation
============================================================================
*/



#include "common.h"

// Function to generate numeric password
void generate_numeric(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Limit password length
   for (int i = 0; i < length; i++) {
       password[i] = '0' + rand() % 10; // Random numeric characters
   }
   password[length] = '\0'; // Null-terminate the password
}


// Function to generate alphabetic password
void generate_alpha(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Limit password length
   for (int i = 0; i < length; i++) {
       password[i] = 'a' + rand() % 26; // Random lowercase letters
   }
   password[length] = '\0'; // Null-terminate the password
}


// Function to generate mixed password (numeric and alphabetic)
void generate_mixed(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Limit password length
   for (int i = 0; i < length; i++) {
       int type = rand() % 2; // Randomly choose numeric or alphabetic
       password[i] = (type == 0) ? ('0' + rand() % 10) : ('a' + rand() % 26); // Random character
   }
   password[length] = '\0'; // Null-terminate the password
}


// Function to generate secure password (includes special characters)
void generate_secure(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Limit password length
   const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()"; // Character set
   int charset_size = sizeof(charset) - 1; // Calculate size of charset array
   for (int i = 0; i < length; i++) {
       password[i] = charset[rand() % charset_size]; // Randomly select from charset
   }
   password[length] = '\0'; // Null-terminate the password
}


int main(void) {
   #if defined WIN32
   WSADATA wsa_data;
   int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
   if (result != 0) {
       printf("Error at WSAStartup\n");
       return -1;
   }
   #endif

   printf("Using port %d for communication...\n", PROTOPORT);
   int server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (server_socket < 0) {
       perror("Socket creation failed");
       clearwinsock();
       return -1;
   }

   struct sockaddr_in sad;
   memset(&sad, 0, sizeof(sad));
   sad.sin_family = AF_INET;
   sad.sin_addr.s_addr = INADDR_ANY;
   sad.sin_port = htons(PROTOPORT);
   if (bind(server_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
       perror("Binding failed");
       closesocket(server_socket);
       clearwinsock();
       return -1;
   }

   if (listen(server_socket, 5) < 0) {
       perror("Listen failed");
       closesocket(server_socket);
       clearwinsock();
       return -1;
   }

   printf("Server is running and waiting for connections...\n");
   srand((unsigned) time(NULL));
   while (1) {
       struct sockaddr_in cad;
       int client_socket;
       int client_len = sizeof(cad);
       client_socket = accept(server_socket, (struct sockaddr *)&cad, &client_len);
       if (client_socket < 0) {
           perror("Accept failed");
           closesocket(server_socket);
           clearwinsock();
           return -1;
       }

       printf("New connection from %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));
       char buffer[BUFFERSIZE];
       int bytes_received;
       while ((bytes_received = recv(client_socket, buffer, BUFFERSIZE - 1, 0)) > 0) {
           buffer[bytes_received] = '\0'; // Null-terminate the received data
           printf("Received: '%s'\n", buffer); // Debug print the input
           // Remove newline character if present
           buffer[strcspn(buffer, "\n")] = 0;
           // Check for 'q' to quit the connection
           if (strcmp(buffer, "q") == 0) {
               printf("Client requested to close the connection.\n");
               break;
           }
           // Extract the password type and length
           char type;
           int length;
           if (sscanf(buffer, "%c %d", &type, &length) != 2) {
               send(client_socket, "Invalid input format. Use: <type> <length>\n", 44, 0);
               continue;
           }
           // Check if the password length is valid
           if (length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
               const char *error_msg = "Invalid password length. Must be between 6 and 32.\n";
               send(client_socket, error_msg, strlen(error_msg), 0);
               continue;
           }
           char password[MAX_PASSWORD_LENGTH + 1];
           // Generate the password based on the type
           switch (type) {
               case 'n': // Numeric password
                   generate_numeric(password, length);
                   break;
               case 'a': // Alphabetic password
                   generate_alpha(password, length);
                   break;
               case 'm': // Mixed password
                   generate_mixed(password, length);
                   break;
               case 's': // Secure password with special characters
                   generate_secure(password, length);
                   break;
               default:
                   send(client_socket, "Invalid password type. Use n, a, m, or s.\n", 41, 0);
                   continue;
           }
           printf("Generated password: %s\n", password);
           send(client_socket, password, strlen(password), 0);
       }
       closesocket(client_socket); // Close the client connection
       printf("Client connection closed.\n");
   }
   closesocket(server_socket); // Close the server socket
   clearwinsock(); // Cleanup
   return 0;
}

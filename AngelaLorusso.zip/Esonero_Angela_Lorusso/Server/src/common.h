/*
* common.h
*
*  Created on: 08/11/2024
*      Author: Angela Lorusso (Matricola:798413)
*/


#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>    // Standard I/O functions
#include <stdlib.h>   // Standard library functions
#include <string.h>   // String manipulation functions
#include <time.h>     // Time functions for random number generation
#if defined WIN32
#include <winsock2.h>   // Windows socket library
#include <ws2tcpip.h>   // Windows TCP/IP-specific functions
#define closesocket(s) closesocket(s)  // Define closesocket for Windows
#else
#include <sys/socket.h>  // Sockets for UNIX-like systems
#include <arpa/inet.h>   // Internet address manipulation
#include <unistd.h>      // UNIX-specific functions
#define closesocket(s) close(s)       // Define closesocket for UNIX
#define clearwinsock()  // No-op for UNIX, only needed on Windows
#endif

#define PROTOPORT 27015            // Default port for server communication
#define BUFFERSIZE 1024            // Max buffer size for data transmission
#define MIN_PASSWORD_LENGTH 6      // Min password length
#define MAX_PASSWORD_LENGTH 32     // Max password length


// Prototypes for password generation functions
void generate_numeric(char *password, int length);
void generate_alpha(char *password, int length);
void generate_mixed(char *password, int length);
void generate_secure(char *password, int length);

#if defined WIN32
void clearwinsock() {
   WSACleanup();  // Clean up Winsock resources on Windows
}
#endif // WIN32
#endif // COMMON_H




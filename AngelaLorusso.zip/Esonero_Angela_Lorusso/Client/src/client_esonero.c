/*
============================================================================
Name        : client_esonero.c
Author      : Angela Lorusso (Matricola:798413)
Version     : 08/11/2024
Copyright   : Your copyright notice
Description : client creation
============================================================================
*/



#include "common.h"

// Function to handle errors by printing the error message
void errorhandler(const char *error_message) {
   fprintf(stderr, "%s\n", error_message);
}


// Main client function
int main(void) {
   setbuf(stdout, NULL);
   // Initializing Winsock for Windows
   #if defined WIN32
   WSADATA wsa_data;
   int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
   if (result != 0) {
       fprintf(stderr, "Error at WSAStartup\n");
       return -1;
   }
   #endif

   // Create client socket for communication
   int c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (c_socket < 0) {
       errorhandler("Socket creation failed.");
       #if defined WIN32
       clearwinsock();
       #endif
       return -1;
   }

   // Setting up the server's address details
   struct sockaddr_in sad;
   memset(&sad, 0, sizeof(sad));
   sad.sin_family = AF_INET;
   sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // Server's IP address
   sad.sin_port = htons(PROTOPORT);              // Server's port
   // Attempt to connect to the server
   if (connect(c_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
       errorhandler("Failed to connect to server.");
       closesocket(c_socket);
       #if defined WIN32
       clearwinsock();
       #endif
       return -1;
   }
   printf("Connected to server.\n");
   char request[BUFFERSIZE];
   char response[BUFFERSIZE];
   int password_length;

   // Main loop for sending and receiving password requests
   while (1) {
       printf("Enter request (n/a/m/s <length>), or 'q' to quit: ");
       fgets(request, BUFFERSIZE, stdin);
       // Remove the newline character and check input validity
       request[strcspn(request, "\n")] = 0;
       // Check if the user wants to quit
       if (strcmp(request, "q") == 0) {
           printf("Exiting program... Closing connection.\n");
           break;
       }
       // Ensure the input is in the correct format
       if (strlen(request) < 3) {
           printf("Invalid input. Format: <type> <length>\n");
           continue;
       }
       // Extract password length from the request
       if (sscanf(request + 2, "%d", &password_length) != 1 ||
           password_length < MIN_PASSWORD_LENGTH ||
           password_length > MAX_PASSWORD_LENGTH) {
           printf("Invalid length. Must be between %d and %d.\n",
                  MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
           continue;
       }
       // Send the request to the server
       if (send(c_socket, request, strlen(request), 0) < 0) {
           errorhandler("Failed to send data to server.");
           break;
       }
       // Receive the generated password from the server
       int bytes_rcvd = recv(c_socket, response, BUFFERSIZE - 1, 0);
       if (bytes_rcvd <= 0) {
           errorhandler("Failed to receive data from server.");
           break;
       }
       response[bytes_rcvd] = '\0'; // Null-terminate the received string
       printf("Generated password: %s\n", response); // Display the generated password
   }
   // Clean up
   closesocket(c_socket);
   #if defined WIN32
   clearwinsock();
   #endif
   return 0;
}
